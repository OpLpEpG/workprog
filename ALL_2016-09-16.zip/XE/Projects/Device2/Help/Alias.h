

HELP_MAIN    = Help.htm;
HELP_DELAY   = Devices\Delay.htm;
HELP_METROL  = Metrol\Metrology.htm;
HELP_METROL_INCLIN = Metrol\Metrology.Inclin.htm;
